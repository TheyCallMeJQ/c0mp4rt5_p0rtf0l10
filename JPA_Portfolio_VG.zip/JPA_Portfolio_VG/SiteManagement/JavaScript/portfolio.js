

/*
   portfolio.js
   A JavaScript file for the management of the visual display of the portfolio past works assets.
*/

 /**A function to be triggered on click of the privacy disclaimer button at the bottom of the page.*/
function disclaimer()
{
    alert("I was told I had to provide these for the webpages I make, and so:\nPrivacy Assurance: \n" + "In all seriousness, I genuinely have nothing to gain from spreading your data to the world.\n" + "Therefore, rest easy.\n" + "And if at any point it turns out that I was lying just now,\nI, Jacques-Philippe Amiot, the sole creator of this webpage, do solemnly swear that I will eat my shorts.");
}

/**A function to call the clock() function every 100ms, or every second.*/
function time()
{
    setInterval("clock();", 100);
}

/**A function to fill the document element with id "clock" with the current time.*/
function clock()
{
    var date = new Date();
    //day of the week, month, day of the month, year, hours, minutes, seconds
    var weekday = date.getDay();
    var month = date.getMonth();
    var monthday = date.getDate();
    var year = date.getFullYear();
    var hour = date.getHours();
    if (hour < 10)     
    {
        hour = "0" + hour;   
    }
    var minute = date.getMinutes();
    if (minute < 10)
    {
        minute = "0" + minute;   
    }
    var second = date.getSeconds();
    if (second < 10)
    {
        second = "0" + second;   
    }
    switch(weekday)
    {
        case 0:
            {
                weekday = "Sunday";
                break;
            }
        case 1:
            {
                weekday = "Monday";
                break;
            }
        case 2:
            {
                weekday = "Tuesday";
                break;
            }
        case 3:
            {
                weekday = "Wednesday";
                break;
            }
        case 4:
            {
                weekday = "Thursday";
                break;
            }
        case 5:
            {
                weekday = "Friday";
                break;
            }
        case 6:
            {
                weekday = "Saturday";
                break;
            }
        default:
            {
                window.alert("Impossible case; weekday");   
            }
    }//end switch
                
    switch(month)
    {
        case 0://january
            {
                month = "January";
                break;
            }
        case 1:
            {
                month = "February";
                break;
            }
        case 2:
            {
                month = "March"; 
                break;
            }
        case 3:
            {
                month = "April";
                break;
            }
        case 4:
            {
                month = "May";   
                break;
            }
        case 5:
            {
                month = "June";
                break;
            }
        case 6:
            {
                month = "July";   
                break;
            }
        case 7:
            {
                month = "August";  
                break;
            }
        case 8:
            {
                month = "September";  
                break;
            }
        case 9:
            {
                month = "October";
                break;
            }
        case 10:
            {
                month = "November";
                break;
            }
        case 11:
            {
                month = "December";   
                break;
            }
        default:
            {
                //impossible.
                window.alert("Error in month switch");
                break;
            }
    }//end switch
        
        //day of the week, month, day of the month, year, hours, minutes, seconds
        var dateinfo = weekday + ", " + month + " " + monthday + ", " + year + " " + hour + ":" + minute + ":" + second;
        window.document.getElementById("clock").innerHTML = dateinfo;
}
